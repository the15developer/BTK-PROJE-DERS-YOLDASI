from flask import Flask, render_template
import markdown
import uuid

from flask import request, jsonify
import json
import google.generativeai as genai

genai.configure(api_key="AIzaSyAjaRftzV0zwy-If4WSDzD_uX5XeVmHp1w")

model = genai.GenerativeModel("models/gemini-2.5-flash")  # Güncel ve desteklenen model

from flask import Flask

app = Flask(__name__)



@app.route('/')
def Login():
    return render_template('login.html')  # templates/index.html dosyasını gösterir

@app.route('/home')
def home():
    return render_template('index.html')  # diğer sayfalar da aynı şekilde

@app.route('/courses')
def courses():
    return render_template('courses.html')  # diğer sayfalar da aynı şekilde

@app.route('/goals')
def goals():
    return render_template('goals.html')  # diğer sayfalar da aynı şekilde

@app.route('/progress')
def progress():
    return render_template('progress.html')  # diğer sayfalar da aynı şekilde

@app.route('/bookmarks')
def bookmarks():
    return render_template('bookmarks.html')  # diğer sayfalar da aynı şekilde

@app.route('/profile')
def profile():
    return render_template('profile.html')  # diğer sayfalar da aynı şekilde



# JSON dosyasını oku
def load_users():
    with open("data/veriler.json", "r", encoding="utf-8") as f:
        return json.load(f)
    

#LOGIN KODU

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    users = load_users()

    for user in users:
        if user["email"] == email and user["sifre"] == password:
            return jsonify({"success": True, "ad": user["ad"], "email": user["email"]})

    return jsonify({"success": False, "message": "Geçersiz e-posta veya şifre."}), 401


#DERSLERI GOSTERME KODU 

@app.route('/get_courses', methods=['POST'])
def get_courses():
    data = request.get_json()
    email = data.get("email")
    users = load_users()
    
    for user in users:
        if user["email"] == email:
            return jsonify({"success": True, "kurslar": user.get("kurslar", [])})
    
    return jsonify({"success": False, "message": "Kullanıcı bulunamadı."}), 404


#MOTIVASYON SOZU


@app.route('/motivasyon-sozu')
def motivasyon_sozu():
    try:
        response = model.generate_content("orta uzunlukta ve motive edici TEK bir Türkçe başarı sözü üret ve cevabin sadece sozu icersin. Kalin fontla yazma. ")
        #print("Response objesi:", response)
        #print("Response text:", getattr(response, 'text', 'text attribute yok'))
        result_text = response.text.strip() if hasattr(response, 'text') else "Metin bulunamadı."
        print("Sonuç metni:", result_text)
       

        return jsonify({"sozu": result_text})
    except Exception as e:
        print("Hata oluştu:", e)
        return jsonify({"sozu": "Başarı, çabanın meyvesidir."})
    

@app.route('/chat', methods=['POST'])
def gemini_chat():
    try:
        data = request.get_json()
        user_message = data.get("message", "")
        response = model.generate_content(user_message)

        raw_text = response.text.strip() if hasattr(response, 'text') else "Yanıt alınamadı."
        html_text = markdown.markdown(raw_text, extensions=["fenced_code"])

        return jsonify({"response": html_text})
    except Exception as e:
        print("Chatbot hatası:", e)
        return jsonify({"response": "<p>❌ Bir hata oluştu.</p>"}), 500

#gunluk hedef kodu

def gemini_daily_goal_recommendation(unfinished_courses):
    prompt = "Kullanıcının tamamlamadığı kurslar ve modüller:\n"
    for kurs in unfinished_courses:
        prompt += f"- {kurs['ad']}:\n"
        for mod in kurs['moduller']:
            prompt += f"  * {mod['baslik']} (%{mod['tamamlanma']})\n"
    prompt += "\nLütfen kullanıcı için bugün tamamlaması gereken en uygun modülü öner,sadece kurs ismi - modul basligi seklinde yaz\n"

    # Gemini model generate_content kullanımı
    response = model.generate_content(prompt)
    result_text = response.text.strip() if hasattr(response, 'text') else "Öneri alınamadı."
    return result_text



@app.route("/get-daily-goal", methods=["POST"])
def get_daily_goal():
    data = request.get_json()
    email = data.get("email")
    if not email:
        return jsonify({"error": "Email bilgisi gerekli"}), 400

    users = load_users()
    user = next((u for u in users if u.get("email") == email), None)
    if not user:
        return jsonify({"error": "Kullanıcı bulunamadı"}), 404

    unfinished_courses = []
    module_lookup = {}  # -> modül ismine göre oranı bulmak için

    for kurs in user.get("kurslar", []):
        if kurs.get("durum") != "Devam Ediyor":
            continue

        unfinished_moduller = []
        for mod in kurs.get("moduller", []):
            oran = int(mod.get("tamamlanma", "0%").replace("%", ""))
            if oran < 100:
                unfinished_moduller.append(mod)
                # lookup için ekle
                module_lookup[(kurs["ad"], mod["baslik"])] = oran

        if unfinished_moduller:
            unfinished_courses.append({
                "ad": kurs["ad"],
                "moduller": unfinished_moduller
            })

    if not unfinished_courses:
        return jsonify({"recommendation": "Tüm modüller tamamlandı! 🎉"})

    try:
        recommendation_text = gemini_daily_goal_recommendation(unfinished_courses)

        # Tahmini format: "Python 101 - Fonksiyonlar"
        parcalar = recommendation_text.split(" - ")
        if len(parcalar) == 2:
            kurs_adi, modul_baslik = parcalar
            oran = module_lookup.get((kurs_adi.strip(), modul_baslik.strip()), 0)
        else:
            oran = 0

        return jsonify({
            "recommendation": recommendation_text,
            "tamamlanma_orani": oran  # frontend'e oranı da gönder
        })

    except Exception as e:
        print("Gemini öneri hatası:", e)
        return jsonify({"error": "Öneri alınırken hata oluştu."}), 500



#HEDEFLERI CEKME KODU 


@app.route('/get_hedefler', methods=['POST'])
def get_hedefler():
    data = request.get_json()
    email = data.get('email')

    try:
        with open('data/veriler.json', 'r', encoding='utf-8') as f:
            users = json.load(f)

        for user in users:
            if user['email'] == email:
                return jsonify({
                    'status': 'success',
                    'hedefler': user['hedefler']
                })

        return jsonify({'status': 'not_found', 'message': 'Kullanıcı bulunamadı'}), 404

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


#HEDEF EKLEME KODU

@app.route('/hedef_ekle', methods=['POST'])
def hedef_ekle():
    data = request.get_json()
    email = data.get("email")
    baslik = data.get("baslik")
    aciklama = data.get("aciklama", "")

    if not email or not baslik:
        return jsonify({"status": "fail", "message": "Eksik bilgi"}), 400

    try:
        with open("data/veriler.json", "r", encoding="utf-8") as f:
            users = json.load(f)

        user_found = False

        for user in users:
            if user["email"] == email:
                yeni_hedef = {
                    "id": f"g{str(uuid.uuid4())[:8]}",
                    "baslik": baslik,
                    "aciklama": aciklama,
                    "tamamlandi": False
                }

                if "hedefler" not in user:
                    user["hedefler"] = []

                user["hedefler"].append(yeni_hedef)
                user_found = True
                break

        if not user_found:
            return jsonify({"status": "fail", "message": "Kullanıcı bulunamadı"}), 404

        with open("veriler.json", "w", encoding="utf-8") as f:
            json.dump(users, f, ensure_ascii=False, indent=2)

        return jsonify({"status": "success", "message": "Hedef eklendi"})

    except Exception as e:
        return jsonify({"status": "fail", "message": str(e)}), 500


#YER IMLERI GOSTERME KODU 

def load_bookmarks():
    with open('data/veriler.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    # Kullanıcının bookmarks alanını döndür
    # Burada sadece ilk kullanıcı alınıyor, istersen kullanıcıya göre filtreleyebilirsin
    return data[0].get('bookmarks', [])

@app.route('/api/bookmarks')
def api_bookmarks():
    bookmarks = load_bookmarks()
    return jsonify(bookmarks)

#KURS EKLEME

@app.route('/add_course', methods=['POST'])
def add_course():
    data = request.get_json()
    email = data.get("email")
    if not email:
        return jsonify({"success": False, "message": "Email eksik"}), 400

    users = load_users()
    user_found = False

    for user in users:
        if user["email"] == email:
            user_found = True
            if "kurslar" not in user:
                user["kurslar"] = []

            # Yeni kurs ID'si ata
            new_id = max([k.get("id", 100) for k in user["kurslar"]] + [100]) + 1
            yeni_kurs = {
                "id": new_id,
                "ad": data["ad"],
                "egitmen": data["egitmen"],
                "baslangic_tarihi": data["baslangic_tarihi"],
                "durum": data["durum"]
            }
            user["kurslar"].append(yeni_kurs)

            # JSON dosyasını güncelle
            with open("data/veriler.json", "w", encoding="utf-8") as f:
                json.dump(users, f, ensure_ascii=False, indent=2)

            return jsonify({"success": True})

    if not user_found:
        return jsonify({"success": False, "message": "Kullanıcı bulunamadı."}), 404


if __name__ == "__main__":
    app.run(debug=True)

